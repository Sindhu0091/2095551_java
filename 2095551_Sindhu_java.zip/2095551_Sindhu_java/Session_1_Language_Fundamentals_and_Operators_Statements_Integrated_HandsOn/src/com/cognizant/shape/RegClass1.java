package com.cognizant.shape;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RegClass1 {
	static Scanner sc = new Scanner(System.in);
	//Declare variable
	static List<String>name = new ArrayList<String>();
	static List<Long>phoneNumber = new ArrayList<Long>();
	static List<String>eMailID = new ArrayList<String>();
	static List<Long>aadhaarNum = new ArrayList<Long>();
	static int maxroom = 50;
	static int regcount = 0;
	static int roomcount = 0;
	
	// print the menu
	static void menu()
	{
	      System.out.println(" Welcome");
	      System.out.println("1. Registeration Process - To make a new registration");
	      System.out.println("2. Room Details - Book a room, check room status and availabilities");
	      System.out.println("3. All booking details of the rooms in the hotel");
	      System.out.println("4. Email change or updation");
	      System.out.println("5. All Customers");
	      System.out.println("6. Quit");
	      System.out.println("Select an option");
	}
	
	// Registration process
	static void register()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter your Name : ");
		name.add(sc.nextLine());
		System.out.println("Please enter your Phone number : ");
		phoneNumber.add(sc.nextLong());
		System.out.println("Please enter your E-mail ID : ");
		eMailID.add(sc.next());
		System.out.println("Please enter your Aadhaar Number : ");
		aadhaarNum.add(sc.nextLong());
		
		sc.nextLine();
		System.out.println(name);
		System.out.println(phoneNumber);
		System.out.println(eMailID);
		System.out.println(aadhaarNum);
		System.out.println("Press enter");
		regcount++;
		
		sc.nextLine();
		System.out.println("Please select an option");
		System.out.println("0. I want to register for another person");
		System.out.println("1. Booking for One person");
		int reg = sc.nextInt();
		if(reg == 0)
		{
			register();
		}
		else 
		{
			System.out.println(" ");
		}
		sc.nextLine();
		System.out.println("Please select an option");
		System.out.println("0. I would like to book a room");
		System.out.println("1. I would like to open menu");
		System.out.println("2. Quit");
		int check = sc.nextInt();
		if(check == 0)
		{
			roomBooking();
		}
		else if(check == 1)
		{
			MainList1.main(null);
		}
		else
		{
			System.out.println(" ");
		}
	}
	
	// Booking room
	
	static void roomBooking()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please select an option");
		System.out.println("0. Continue Booking");
		System.out.println("1. Menu");
		int x = sc.nextInt();
		if(x == 0)
		{
			int n;
			System.out.println("Please enter the number of rooms");
			n = sc.nextInt();
			for(int i=1;i<=n;i++)
			{
				System.out.println("You are allocated with the room number : "+ i);
				roomcount++;
			}
			System.out.println("Thankyou, your booking is been confirmed");
			System.out.println("Vacant rooms count : " + (maxroom-roomcount));
			quit();
		}
		else 
		{
			MainList1.main(null);
		}
		
	}
	
	//Room details
	
	
	static void roomDetails()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please select an option");
		System.out.println("0. Continue checking the room details");
		System.out.println("1. Menu");
		int y = sc.nextInt();
		if(y == 0)
		{
			for(int i=1;i<=roomcount;i++)
			{
				System.out.println("Room number " + i + " is Occupied");
			}
			System.out.println("Vacant rooms count are : " + (maxroom-roomcount));
			quit();
		}
		else
		{
			MainList1.main(null);
		}
	}	
	
	// email change or updation
	
	static void emailUpdation()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please select an option");
		System.out.println("0. Continue with e Mail updation");
		System.out.println("1. Menu");
		int z = sc.nextInt();
		if(z == 0)
		{
	
			
			System.out.println("Please enter your email : ");
			ArrayList a = new ArrayList();
			a.add(sc.next());
			eMailID =a;
			System.out.println("Your upadted e mail Id is: " +eMailID );
			quit();
		}
		else
		{
			MainList1.main(null);
		}
	}
	static List  allCustomers(){
		return name;
	}
	
	static void quit(){
		System.out.println(" Thankyou for using our application");
    	
	}
}
