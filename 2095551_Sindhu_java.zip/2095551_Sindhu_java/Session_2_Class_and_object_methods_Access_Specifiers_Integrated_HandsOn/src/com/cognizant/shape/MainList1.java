
package com.cognizant.shape;

import java.util.Scanner;

public class MainList1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int select;
	      RegClass1.menu();
	      select = sc.nextInt();
	      switch (select)
	      {
	      case 1:
        	  System.out.println("Please enter your details");
        	  sc.nextLine();
        	  RegClass1.register();
              	  break;
              case 2:
        	  System.out.println("Welcome to room booking process");
        	  sc.nextLine();
        	  RegClass1.roomBooking();
        	  break;
              case 3:
              	  System.out.println("Fetching the data of all available rooms...");
                  sc.nextLine();
                  RegClass1.roomDetails();
                  break;
              case 4:
        	  System.out.println("Welcome to Phone NUmber updation process");
        	  sc.nextLine();
        	  RegClass1.emailUpdation();
        	  break;
              case 5:
              	  System.out.println("Fetching the data of all customers...");
              	  sc.nextLine();
              	  RegClass1.allCustomers();
              	  break;
              case 6:
               	  System.out.println("Quitting Process...");
               	  sc.nextLine();
              	  RegClass1.quit();
              	  break;
              default:
              	System.out.println("Invalid Option");
              	break;
	      }
	}

}
