package com.cognizant;

public class HomePage {

}
