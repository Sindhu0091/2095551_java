package com.cognizant;

public class CustoFunc {

}
